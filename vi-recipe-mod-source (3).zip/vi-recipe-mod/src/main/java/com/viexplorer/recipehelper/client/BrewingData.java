package com.viexplorer.recipehelper.client;

import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.Potions;
import net.minecraft.registry.entry.RegistryEntry;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Bảng công thức pha thuốc (Brewing Stand) của Minecraft 1.21.4.
 * Mỗi công thức: thuốc gốc + nguyên liệu = thuốc kết quả.
 * Tên tiếng Việt dùng để tìm kiếm; tên tiếng Anh/ngôn ngữ game lấy từ game.
 */
public final class BrewingData {

    public record Entry(ItemStack base, ItemStack ingredient, ItemStack result, String viResult) {}

    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static final Map<Item, String> INGREDIENT_VI = new HashMap<>();

    static {
        // Nước -> Thuốc nhạt (Awkward) bằng hạt địa ngục
        ingredient(Items.NETHER_WART, "hạt địa ngục");
        add(Potions.WATER, Items.NETHER_WART, Potions.AWKWARD, "Thuốc nhạt");

        // Từ Thuốc nhạt
        add(Potions.AWKWARD, Items.GLISTERING_MELON_SLICE, Potions.HEALING, "Thuốc hồi máu");
        add(Potions.AWKWARD, Items.GOLDEN_CARROT, Potions.NIGHT_VISION, "Thuốc nhìn đêm");
        add(Potions.AWKWARD, Items.MAGMA_CREAM, Potions.FIRE_RESISTANCE, "Thuốc kháng lửa");
        add(Potions.AWKWARD, Items.RABBIT_FOOT, Potions.LEAPING, "Thuốc nhảy cao");
        add(Potions.AWKWARD, Items.PUFFERFISH, Potions.WATER_BREATHING, "Thuốc thở dưới nước");
        add(Potions.AWKWARD, Items.SUGAR, Potions.SWIFTNESS, "Thuốc nhanh nhẹn");
        add(Potions.AWKWARD, Items.BLAZE_POWDER, Potions.STRENGTH, "Thuốc sức mạnh");
        add(Potions.AWKWARD, Items.SPIDER_EYE, Potions.POISON, "Thuốc độc");
        add(Potions.AWKWARD, Items.PHANTOM_MEMBRANE, Potions.SLOW_FALLING, "Thuốc chậm rơi");
        add(Potions.AWKWARD, Items.TURTLE_SCUTE, Potions.TURTLE_MASTER, "Thuốc rùa");
        add(Potions.AWKWARD, Items.GHAST_TEAR, Potions.REGENERATION, "Thuốc hồi sinh");

        // Biến đổi thuốc đã có
        add(Potions.HEALING, Items.FERMENTED_SPIDER_EYE, Potions.HARMING, "Thuốc gây hại");
        add(Potions.SWIFTNESS, Items.FERMENTED_SPIDER_EYE, Potions.SLOWNESS, "Thuốc làm chậm");
        add(Potions.NIGHT_VISION, Items.FERMENTED_SPIDER_EYE, Potions.INVISIBILITY, "Thuốc tàng hình");

        // Tăng cấp (Glowstone) và kéo dài thời gian (Redstone)
        add(Potions.HEALING, Items.GLOWSTONE_DUST, Potions.STRONG_HEALING, "Thuốc hồi máu mạnh");
        add(Potions.STRENGTH, Items.GLOWSTONE_DUST, Potions.STRONG_STRENGTH, "Thuốc sức mạnh mạnh");
        add(Potions.SWIFTNESS, Items.GLOWSTONE_DUST, Potions.STRONG_SWIFTNESS, "Thuốc nhanh nhẹn mạnh");
        add(Potions.NIGHT_VISION, Items.REDSTONE, Potions.LONG_NIGHT_VISION, "Thuốc nhìn đêm (lâu)");
        add(Potions.SWIFTNESS, Items.REDSTONE, Potions.LONG_SWIFTNESS, "Thuốc nhanh nhẹn (lâu)");
        add(Potions.FIRE_RESISTANCE, Items.REDSTONE, Potions.LONG_FIRE_RESISTANCE, "Thuốc kháng lửa (lâu)");
        add(Potions.INVISIBILITY, Items.REDSTONE, Potions.LONG_INVISIBILITY, "Thuốc tàng hình (lâu)");

        // Thuốc ném (Splash): thuốc + Thuốc súng. Thuốc lưu (Lingering): thuốc ném + Hơi rồng.
        List<PV> basics = List.of(
                new PV(Potions.HEALING, "hồi máu"),
                new PV(Potions.HARMING, "gây hại"),
                new PV(Potions.SWIFTNESS, "nhanh nhẹn"),
                new PV(Potions.SLOWNESS, "làm chậm"),
                new PV(Potions.POISON, "độc"),
                new PV(Potions.STRENGTH, "sức mạnh"),
                new PV(Potions.REGENERATION, "hồi sinh"),
                new PV(Potions.FIRE_RESISTANCE, "kháng lửa"),
                new PV(Potions.INVISIBILITY, "tàng hình"),
                new PV(Potions.NIGHT_VISION, "nhìn đêm"),
                new PV(Potions.LEAPING, "nhảy cao"),
                new PV(Potions.WATER_BREATHING, "thở dưới nước"),
                new PV(Potions.SLOW_FALLING, "chậm rơi"),
                new PV(Potions.TURTLE_MASTER, "rùa")
        );
        for (PV p : basics) {
            addStack(potion(Items.POTION, p.potion()), Items.GUNPOWDER,
                    potion(Items.SPLASH_POTION, p.potion()), "Thuốc ném " + p.vi());
            addStack(potion(Items.SPLASH_POTION, p.potion()), Items.DRAGON_BREATH,
                    potion(Items.LINGERING_POTION, p.potion()), "Thuốc lưu " + p.vi());
        }

        // Kéo dài thời gian bằng Redstone (các loại chưa có ở trên)
        List<Upgrade> longs = List.of(
                new Upgrade(Potions.LEAPING, Potions.LONG_LEAPING, "nhảy cao"),
                new Upgrade(Potions.WATER_BREATHING, Potions.LONG_WATER_BREATHING, "thở dưới nước"),
                new Upgrade(Potions.POISON, Potions.LONG_POISON, "độc"),
                new Upgrade(Potions.REGENERATION, Potions.LONG_REGENERATION, "hồi sinh"),
                new Upgrade(Potions.SLOWNESS, Potions.LONG_SLOWNESS, "làm chậm"),
                new Upgrade(Potions.STRENGTH, Potions.LONG_STRENGTH, "sức mạnh"),
                new Upgrade(Potions.SLOW_FALLING, Potions.LONG_SLOW_FALLING, "chậm rơi"),
                new Upgrade(Potions.TURTLE_MASTER, Potions.LONG_TURTLE_MASTER, "rùa")
        );
        for (Upgrade u : longs) {
            addStack(potion(Items.POTION, u.plain()), Items.REDSTONE,
                    potion(Items.POTION, u.upgraded()), "Thuốc " + u.vi() + " (lâu)");
        }

        // Tăng cấp bằng Glowstone (các loại chưa có ở trên)
        List<Upgrade> stronger = List.of(
                new Upgrade(Potions.HARMING, Potions.STRONG_HARMING, "gây hại"),
                new Upgrade(Potions.POISON, Potions.STRONG_POISON, "độc"),
                new Upgrade(Potions.REGENERATION, Potions.STRONG_REGENERATION, "hồi sinh"),
                new Upgrade(Potions.SLOWNESS, Potions.STRONG_SLOWNESS, "làm chậm"),
                new Upgrade(Potions.TURTLE_MASTER, Potions.STRONG_TURTLE_MASTER, "rùa")
        );
        for (Upgrade u : stronger) {
            addStack(potion(Items.POTION, u.plain()), Items.GLOWSTONE_DUST,
                    potion(Items.POTION, u.upgraded()), "Thuốc " + u.vi() + " mạnh");
        }

        // Tên tiếng Việt cho nguyên liệu (để tìm kiếm)
        ingredient(Items.GUNPOWDER, "thuốc súng");
        ingredient(Items.DRAGON_BREATH, "hơi rồng");
        ingredient(Items.GLISTERING_MELON_SLICE, "dưa lưới phát sáng");
        ingredient(Items.GOLDEN_CARROT, "cà rốt vàng");
        ingredient(Items.MAGMA_CREAM, "kem magma");
        ingredient(Items.RABBIT_FOOT, "chân thỏ");
        ingredient(Items.PUFFERFISH, "cá nóc");
        ingredient(Items.SUGAR, "đường");
        ingredient(Items.BLAZE_POWDER, "bột blaze");
        ingredient(Items.SPIDER_EYE, "mắt nhện");
        ingredient(Items.FERMENTED_SPIDER_EYE, "mắt nhện lên men");
        ingredient(Items.PHANTOM_MEMBRANE, "màng phantom");
        ingredient(Items.TURTLE_SCUTE, "vảy rùa");
        ingredient(Items.GHAST_TEAR, "nước mắt ghast");
        ingredient(Items.GLOWSTONE_DUST, "bụi phát sáng");
        ingredient(Items.REDSTONE, "bụi redstone");
    }

    private BrewingData() {}

    private static void ingredient(Item item, String vi) {
        INGREDIENT_VI.put(item, vi);
    }

    /** Thuốc theo loại (Potion) với tên tiếng Việt. */
    private record PV(RegistryEntry<Potion> potion, String vi) {}

    /** Thuốc gốc -> thuốc được nâng cấp (kéo dài hoặc tăng cấp). */
    private record Upgrade(RegistryEntry<Potion> plain, RegistryEntry<Potion> upgraded, String vi) {}

    private static ItemStack potion(Item container, RegistryEntry<Potion> potion) {
        return PotionContentsComponent.createStack(container, potion);
    }

    private static void addStack(ItemStack base, Item ingredient, ItemStack result, String viResult) {
        ENTRIES.add(new Entry(base, new ItemStack(ingredient), result, viResult));
    }

    private static void add(RegistryEntry<Potion> base, Item ingredient, RegistryEntry<Potion> result, String viResult) {
        ENTRIES.add(new Entry(
                PotionContentsComponent.createStack(Items.POTION, base),
                new ItemStack(ingredient),
                PotionContentsComponent.createStack(Items.POTION, result),
                viResult
        ));
    }

    public static List<Entry> all() {
        return ENTRIES;
    }

    /** Lọc công thức theo từ khóa (không phân biệt hoa thường, không dấu). Để trống = trả về tất cả. */
    public static List<Entry> search(String query) {
        String q = norm(query);
        if (q.isEmpty()) {
            return ENTRIES;
        }
        List<Entry> out = new ArrayList<>();
        for (Entry e : ENTRIES) {
            String ingVi = INGREDIENT_VI.getOrDefault(e.ingredient().getItem(), "");
            String haystack = norm(e.viResult() + " " + ingVi + " "
                    + e.ingredient().getName().getString() + " "
                    + e.result().getName().getString());
            if (haystack.contains(q)) {
                out.add(e);
            }
        }
        return out;
    }

    public static String viIngredient(ItemStack stack) {
        return INGREDIENT_VI.getOrDefault(stack.getItem(), "");
    }

    static String norm(String s) {
        String n = s.toLowerCase(Locale.ROOT).replace('đ', 'd');
        n = Normalizer.normalize(n, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.replaceAll("\\s+", " ").trim();
    }
}
